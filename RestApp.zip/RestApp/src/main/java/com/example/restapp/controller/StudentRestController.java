package com.example.restapp.controller;

import java.util.ArrayList;
import java.util.List;

import com.example.restapp.bean.Student;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class StudentRestController {

	@GetMapping("/students")
	public List<Student> getStudents(){
		
		List<Student> students = new ArrayList<Student>();
		students.add(new Student("virat","kohli"));
		students.add(new Student("rohit", "sharma"));
		students.add(new Student("Mahi","Dhoni"));
		students.add(new Student("Jasprit", "Bumra"));
		students.add(new Student("Mohd","Siral"));
		students.add(new Student("KL", "rahul"));
		
		return students;
	}
	
	@GetMapping("/students/{sid}")
	public Student getStudentById(@PathVariable int sid) {
		
		// populate students
		List<Student> students = new ArrayList<Student>();
		students.add(new Student("virat","kohli"));
		students.add(new Student("rohit", "sharma"));
		students.add(new Student("Mahi","Dhoni"));
		students.add(new Student("Jasprit", "Bumra"));
		students.add(new Student("Mohd","Siral"));
		students.add(new Student("KL", "rahul"));
		
		
		return students.get(sid);
		
	}
}
