package com.example.restapi.dao;

import java.util.List;

import com.example.restapi.entity.Employee;

public interface EmployeeDao {

	List<Employee> findAll();
	
	Employee findById(int id);
}
