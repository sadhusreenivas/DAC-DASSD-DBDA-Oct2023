package com.example.restapi.service;

import java.util.List;

import com.example.restapi.entity.Employee;

public interface EmployeeService {

	List<Employee> findAll();
	
	Employee findById(int id);
}
