package com.example.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestCrudApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestCrudApp1Application.class, args);
	}

}
