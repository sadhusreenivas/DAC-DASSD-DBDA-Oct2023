package com.example.restdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataRestApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataRestApp2Application.class, args);
	}

}
