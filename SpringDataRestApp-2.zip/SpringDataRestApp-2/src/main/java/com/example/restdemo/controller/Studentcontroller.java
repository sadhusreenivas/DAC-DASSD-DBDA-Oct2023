package com.example.restdemo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.restdemo.model.Studentdetails;
import com.example.restdemo.service.Studentservice;

@RestController
@RequestMapping(value="/student")
public class Studentcontroller {
	
	@Autowired
	Studentservice studentservice;
	
	@GetMapping("/getStudentDetail/{id}")
	public Optional<Studentdetails> studentdetail(@PathVariable int id){
		
		Optional<Studentdetails> stu = studentservice.getStudentDetails(id);
			
		return stu;
	}
	
	@GetMapping("/getStudentdata")
	public List<Studentdetails> allStudentdetails(){
		
		List<Studentdetails> listofstudent = studentservice.getAllStudent();
		
		return listofstudent;
	}
	
	@PostMapping("/saveStudent")
	public Studentdetails saveStudent(@RequestBody Studentdetails student){
		
		Studentdetails stu = studentservice.saveStudent(student);
		
		return stu;
		
	}
	
	@DeleteMapping("/deleteStudent/{id}")
	public void deleteStudent(@PathVariable int id){
		
		studentservice.deleteStudent(id);
		
	}

}
