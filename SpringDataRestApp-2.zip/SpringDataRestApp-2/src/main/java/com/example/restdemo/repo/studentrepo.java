package com.example.restdemo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.restdemo.model.Studentdetails;

@Repository
public interface studentrepo extends JpaRepository<Studentdetails, Integer> {

	Optional<Studentdetails> findById(int id);

}
