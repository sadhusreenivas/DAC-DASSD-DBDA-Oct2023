package com.example.restdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.restdemo.model.Studentdetails;
import com.example.restdemo.repo.studentrepo;

@Service
public class Studentservice {
	
	@Autowired
	studentrepo repo;
	
	public Optional<Studentdetails> getStudentDetails(int id){
		
		Optional<Studentdetails> student = repo.findById(id);
		
		return student;
	}
	
	public List<Studentdetails> getAllStudent(){
		
		List<Studentdetails> studentlist = repo.findAll();
		
		return studentlist;
		
	}
	
	public Studentdetails saveStudent(Studentdetails student){
		
		Studentdetails stu = repo.save(student);
		
		return stu;
		
	}
	
	public void deleteStudent(int id){
		
		repo.deleteById(id);
		
	}

}
