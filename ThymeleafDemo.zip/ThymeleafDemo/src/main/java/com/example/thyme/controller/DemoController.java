package com.example.thyme.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DemoController {

	@GetMapping("/")
	public String getDate(Model model) {
		
		Date d = new Date();
		model.addAttribute("date", d);
		
		return "currentdate"; // 
	}
}
